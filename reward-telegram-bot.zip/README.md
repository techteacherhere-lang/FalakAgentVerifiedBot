# Telegram Reward Bot — Free Hosting Starter

A production-oriented starter for a Telegram rewards/task bot with:

- Required channel membership verification
- User wallet + immutable transaction ledger
- Tasks and task attempts
- Reward campaigns schema
- Referrals + qualification
- Gift codes
- Withdrawal requests
- Admin approval/rejection/refund
- Admin dashboard
- User search + manual credit
- Channel manager
- Task manager
- Settings
- Audit logs
- Webhook deployment support
- PostgreSQL persistence

## Important

The included task completion button is intentionally a **manual demo flow**. Do not present a user click as proof that an advertisement was actually viewed. For real advertising rewards, connect a legitimate provider that gives you a server-to-server completion callback/webhook and mark the task complete only after validating that callback.

Likewise, a withdrawal becomes `paid` only when an administrator has actually completed the payment.

## 1. Create the Telegram bot

Open Telegram and message `@BotFather`.

Create a bot and copy its token.

Do not publish the token or commit it to Git.

## 2. Create PostgreSQL

A free Supabase project can be used for the database.

Create a project and copy its PostgreSQL connection string.

## 3. Local setup

```bash
git clone <your-repository>
cd reward-telegram-bot
npm install
cp .env.example .env
```

Fill `.env`.

For local development use:

```env
NODE_ENV=development
BASE_URL=http://localhost:3000
```

Then:

```bash
npm start
```

The bot uses polling locally.

Open:

```text
http://localhost:3000/health
http://localhost:3000/admin
```

## 4. Add your required channels

The bot needs appropriate Telegram permissions in channels where it must verify membership.

Log into `/admin`, then add each required channel.

Use the channel's `@username` or numeric chat ID and a working invite URL.

## 5. Free Render deployment

1. Push this project to GitHub.
2. Create a Render account.
3. Create **New → Web Service**.
4. Connect the GitHub repository.
5. Build command:

```bash
npm install
```

6. Start command:

```bash
npm start
```

7. Add environment variables from `.env`.
8. Set:

```env
NODE_ENV=production
BASE_URL=https://YOUR-RENDER-SERVICE.onrender.com
```

Render gives the service a public HTTPS URL.

The app automatically calls Telegram `setWebhook` on startup in production.

## 6. Free-hosting limitations

Free hosting is suitable for development/testing and small hobby deployments, not guaranteed 24/7 production service.

Render's free web services can spin down after inactivity and have an ephemeral filesystem, so this project stores persistent state in PostgreSQL instead of SQLite.

Do not store the database in a local `.db` file on Render.

## 7. Supabase connection

Use a PostgreSQL connection string in:

```env
DATABASE_URL=...
```

The app runs the SQL migration automatically at startup.

## 8. Admin security

Change these immediately:

```env
ADMIN_USERNAME=admin
ADMIN_PASSWORD=VERY_STRONG_PASSWORD
JWT_SECRET=LONG_RANDOM_SECRET
WEBHOOK_SECRET=LONG_RANDOM_SECRET
```

Never commit `.env`.

## 9. Real ad/task integration

The correct production flow is:

```text
User starts task
       ↓
Provider creates/serves task
       ↓
Provider sends signed server callback
       ↓
Your backend validates callback
       ↓
Check unique provider transaction ID
       ↓
Complete task attempt
       ↓
Credit wallet
       ↓
Write ledger entry
```

Never credit money solely because a Telegram button was clicked.

## 10. Real payment integration

The starter intentionally uses manual payout approval.

Production:

```text
Withdrawal request
      ↓
Risk checks
      ↓
Admin/payment provider
      ↓
Payment succeeds
      ↓
Mark withdrawal paid
      ↓
Ledger confirmed
```

If a payment fails/rejects:

```text
Withdrawal rejected
      ↓
Refund balance
      ↓
Ledger refund entry
```

## 11. Suggested next upgrades

- Proper admin role management
- Campaign UI
- Referral milestone campaigns
- Automated legitimate task-provider callbacks
- Telegram Mini App dashboard
- Pagination
- Broadcast queue
- Support tickets
- Fraud review queue
- Rate limiting
- CSRF protection for admin
- 2FA for admin
- Automated backups
- Payment-provider integration
- Better admin UI
