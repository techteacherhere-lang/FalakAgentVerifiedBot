require("dotenv").config();

const express = require("express");
const cookieParser = require("cookie-parser");
const path = require("path");
const { migrate } = require("./db");
const { bot } = require("./bot");
const admin = require("./admin");

const app = express();
app.set("trust proxy", 1);
app.use(express.json({limit:"1mb"}));
app.use(cookieParser());

app.get("/health", (req,res)=>res.json({ok:true,service:"telegram-reward-bot"}));
app.get("/", (req,res)=>res.send("Telegram Reward Bot is running."));
app.use("/admin", express.static(path.join(__dirname,"../public")));
app.use("/admin", admin);

app.post("/telegram/webhook", async (req,res)=>{
  const secret = req.get("X-Telegram-Bot-Api-Secret-Token");
  if (!secret || secret !== process.env.WEBHOOK_SECRET) return res.sendStatus(401);
  try {
    await bot.handleUpdate(req.body);
    res.sendStatus(200);
  } catch (e) {
    console.error("Webhook error:",e);
    res.sendStatus(500);
  }
});

async function main(){
  if (!process.env.BOT_TOKEN) throw new Error("BOT_TOKEN is missing");
  if (!process.env.JWT_SECRET) throw new Error("JWT_SECRET is missing");
  await migrate();

  const port = Number(process.env.PORT || 3000);
  app.listen(port, async ()=>{
    console.log(`Server listening on ${port}`);
    if (process.env.BASE_URL && process.env.NODE_ENV === "production") {
      const webhookUrl = `${process.env.BASE_URL.replace(/\/$/,"")}/telegram/webhook`;
      await bot.telegram.setWebhook(webhookUrl,{secret_token:process.env.WEBHOOK_SECRET,allowed_updates:["message","callback_query"]});
      console.log("Webhook:",webhookUrl);
    } else {
      await bot.launch();
      console.log("Bot launched with polling");
    }
  });

  process.once("SIGINT",()=>bot.stop("SIGINT"));
  process.once("SIGTERM",()=>bot.stop("SIGTERM"));
}

main().catch(err=>{console.error(err);process.exit(1)});
