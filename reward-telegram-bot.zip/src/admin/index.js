const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { query } = require("../db");
const { creditUser, refundWithdrawal, markWithdrawalPaid } = require("../services/wallet");
const { setSetting } = require("../services/settings");

const router = express.Router();
router.use(express.json());

function sign(username) {
  return jwt.sign({ username }, process.env.JWT_SECRET, { expiresIn: "12h" });
}

function auth(req, res, next) {
  try {
    const token = req.cookies?.admin_token;
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    req.admin = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

router.post("/api/login", async (req,res) => {
  const { username, password } = req.body || {};
  const configuredUser = process.env.ADMIN_USERNAME;
  const configuredPassword = process.env.ADMIN_PASSWORD;
  if (username !== configuredUser || password !== configuredPassword) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  res.cookie("admin_token", sign(username), { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 12*60*60*1000 });
  res.json({ ok: true });
});

router.post("/api/logout", (req,res) => {
  res.clearCookie("admin_token");
  res.json({ ok: true });
});

router.get("/api/dashboard", auth, async (req,res) => {
  const [u,t,w,p,r] = await Promise.all([
    query("SELECT COUNT(*)::int n FROM users"),
    query("SELECT COUNT(*)::int n FROM task_attempts WHERE status='completed'"),
    query("SELECT COUNT(*)::int n FROM withdrawals WHERE status='pending'"),
    query("SELECT COALESCE(SUM(amount),0) total FROM wallet_transactions WHERE type IN ('task_reward','referral_reward','gift_code') AND status='confirmed'"),
    query("SELECT COUNT(*)::int n FROM referrals WHERE status='qualified'")
  ]);
  res.json({users:u.rows[0].n, tasks:t.rows[0].n, pendingWithdrawals:w.rows[0].n, rewards:p.rows[0].total, qualifiedReferrals:r.rows[0].n});
});

router.get("/api/users", auth, async (req,res) => {
  const q = String(req.query.q || "").trim();
  const r = await query(`
    SELECT id,telegram_id,username,first_name,balance,lifetime_earned,lifetime_withdrawn,status,suspicious,created_at
    FROM users
    WHERE ($1='' OR telegram_id::text ILIKE '%'||$1||'%' OR username ILIKE '%'||$1||'%' OR first_name ILIKE '%'||$1||'%')
    ORDER BY id DESC LIMIT 100
  `,[q]);
  res.json(r.rows);
});

router.post("/api/users/:id/credit", auth, async (req,res) => {
  try {
    const amount = Number(req.body.amount);
    if (!Number.isFinite(amount) || amount <= 0) return res.status(400).json({error:"Invalid amount"});
    const balance = await creditUser(Number(req.params.id), amount, "admin_adjustment", `ADMIN-${Date.now()}`, req.body.note || "Admin credit");
    await query("INSERT INTO audit_logs(admin_username,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)", [req.admin.username,"credit","user",req.params.id,JSON.stringify({amount,note:req.body.note||""})]);
    res.json({ok:true,balance});
  } catch(e) { res.status(400).json({error:e.message}); }
});

router.get("/api/withdrawals", auth, async (req,res) => {
  const r = await query(`
    SELECT w.*, u.telegram_id,u.username,u.first_name
    FROM withdrawals w JOIN users u ON u.id=w.user_id
    ORDER BY w.created_at DESC LIMIT 200
  `);
  res.json(r.rows);
});

router.post("/api/withdrawals/:id/pay", auth, async (req,res) => {
  try {
    await markWithdrawalPaid(Number(req.params.id), req.body.note || "Marked paid by admin");
    await query("INSERT INTO audit_logs(admin_username,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)", [req.admin.username,"mark_paid","withdrawal",req.params.id,JSON.stringify(req.body)]);
    res.json({ok:true});
  } catch(e) { res.status(400).json({error:e.message}); }
});

router.post("/api/withdrawals/:id/reject", auth, async (req,res) => {
  try {
    await refundWithdrawal(Number(req.params.id), req.body.note || "Withdrawal rejected");
    await query("INSERT INTO audit_logs(admin_username,action,target_type,target_id,details) VALUES($1,$2,$3,$4,$5)", [req.admin.username,"reject_withdrawal","withdrawal",req.params.id,JSON.stringify(req.body)]);
    res.json({ok:true});
  } catch(e) { res.status(400).json({error:e.message}); }
});

router.get("/api/settings", auth, async (req,res) => {
  const r = await query("SELECT * FROM settings ORDER BY key");
  res.json(r.rows);
});

router.post("/api/settings", auth, async (req,res) => {
  const {key,value} = req.body || {};
  if (!key) return res.status(400).json({error:"key required"});
  await setSetting(key,value ?? "");
  res.json({ok:true});
});

router.get("/api/channels", auth, async (req,res) => {
  const r = await query("SELECT * FROM channels ORDER BY id DESC");
  res.json(r.rows);
});

router.post("/api/channels", auth, async (req,res) => {
  const {title,chat_id,username,invite_url,required=true} = req.body || {};
  if (!title || !chat_id) return res.status(400).json({error:"title and chat_id required"});
  const r = await query(`
    INSERT INTO channels(title,chat_id,username,invite_url,required)
    VALUES($1,$2,$3,$4,$5) RETURNING *
  `,[title,chat_id,username||null,invite_url||null,required]);
  res.json(r.rows[0]);
});

router.get("/api/tasks", auth, async (req,res) => {
  const r = await query("SELECT * FROM tasks ORDER BY id DESC");
  res.json(r.rows);
});

router.post("/api/tasks", auth, async (req,res) => {
  const {title,description,type="manual",reward,daily_limit=1,cooldown_seconds=0} = req.body || {};
  if (!title || Number(reward) < 0) return res.status(400).json({error:"Invalid task"});
  const r = await query(`
    INSERT INTO tasks(title,description,type,reward,daily_limit,cooldown_seconds)
    VALUES($1,$2,$3,$4,$5,$6) RETURNING *
  `,[title,description||null,type,Number(reward),Number(daily_limit),Number(cooldown_seconds)]);
  res.json(r.rows[0]);
});

router.post("/api/gift-codes", auth, async (req,res) => {
  const {code,amount,max_uses=1,expires_at=null} = req.body || {};
  if (!code || Number(amount)<=0) return res.status(400).json({error:"Invalid gift code"});
  const r = await query(`
    INSERT INTO gift_codes(code,amount,max_uses,expires_at)
    VALUES($1,$2,$3,$4) RETURNING *
  `,[String(code).trim().toUpperCase(),Number(amount),Number(max_uses),expires_at]);
  res.json(r.rows[0]);
});

router.get("/api/audit", auth, async (req,res) => {
  const r = await query("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200");
  res.json(r.rows);
});

module.exports = router;
