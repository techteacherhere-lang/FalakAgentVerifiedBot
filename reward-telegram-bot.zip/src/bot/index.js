const { Telegraf, Markup } = require("telegraf");
const { query } = require("../db");
const { upsertUser, getUserByTelegramId } = require("../services/users");
const { requiredChannelsJoined } = require("../services/channels");
const { mainMenu, joinKeyboard } = require("./keyboards");
const { listActiveTasks, startTask, completeManualTask } = require("../services/tasks");
const { debitForWithdrawal, history } = require("../services/wallet");
const { stats } = require("../services/referrals");
const { redeem } = require("../services/giftcodes");
const { getSetting } = require("../services/settings");

const bot = new Telegraf(process.env.BOT_TOKEN);

async function getChannels() {
  const r = await query("SELECT * FROM channels WHERE active=true AND required=true ORDER BY id");
  return r.rows;
}

async function isVerified(ctx) {
  const channels = await getChannels();
  if (!channels.length) return true;
  return requiredChannelsJoined(ctx, channels);
}

async function requireVerified(ctx) {
  if (await isVerified(ctx)) return true;
  const channels = await getChannels();
  await ctx.reply("🔒 Please join all required channels, then press Verify.", joinKeyboard(channels));
  return false;
}

async function dashboard(ctx) {
  const u = await getUserByTelegramId(ctx.from.id);
  const currency = await getSetting("currency", "₹");
  return ctx.reply(
`🏠 *${process.env.BOT_NAME || "Reward Hub"}*

💰 Balance: ${currency}${Number(u.balance).toFixed(2)}
🎁 Lifetime earned: ${currency}${Number(u.lifetime_earned).toFixed(2)}
👥 Invite friends and earn rewards.

Choose an option below:`,
    { parse_mode: "Markdown", ...mainMenu() }
  );
}

bot.start(async ctx => {
  try {
    const param = ctx.startPayload || null;
    await upsertUser(ctx.from, param);
    if (!(await isVerified(ctx))) {
      const channels = await getChannels();
      return ctx.reply(
`👋 Welcome to *${process.env.BOT_NAME || "Reward Hub"}*

🎁 Complete tasks and earn rewards.
👥 Invite friends.
💸 Withdraw eligible earnings.

🔒 Join the required channels first.`,
        { parse_mode: "Markdown", ...joinKeyboard(channels) }
      );
    }
    return dashboard(ctx);
  } catch (e) {
    console.error(e);
    return ctx.reply("⚠️ Something went wrong. Please try again.");
  }
});

bot.action("verify", async ctx => {
  await ctx.answerCbQuery();
  if (!(await isVerified(ctx))) {
    const channels = await getChannels();
    return ctx.reply("❌ You have not joined all required channels yet.", joinKeyboard(channels));
  }
  return dashboard(ctx);
});

bot.action("tasks", async ctx => {
  await ctx.answerCbQuery();
  if (!(await requireVerified(ctx))) return;
  const tasks = await listActiveTasks();
  if (!tasks.length) return ctx.reply("📭 No tasks are available right now.", mainMenu());
  for (const t of tasks) {
    await ctx.reply(
`🎁 *${t.title}*
${t.description || ""}
💰 Reward: ${process.env.CURRENCY || "₹"}${Number(t.reward).toFixed(2)}
📌 Daily limit: ${t.daily_limit}`,
      { parse_mode: "Markdown",
        ...Markup.inlineKeyboard([[Markup.button.callback("🚀 Start Task", `task:${t.id}`)]])
      }
    );
  }
});

bot.action(/^task:(\d+)$/, async ctx => {
  await ctx.answerCbQuery();
  if (!(await requireVerified(ctx))) return;
  try {
    const { task, attempt } = await startTask((await getUserByTelegramId(ctx.from.id)).id, Number(ctx.match[1]));
    await ctx.reply(
`🚀 *Task started*

${task.title}

For this starter build, the task uses manual completion verification.
In production, connect a legitimate ad/task provider callback before releasing real rewards.

When you have completed the task, press the button below.`,
      { parse_mode: "Markdown",
        ...Markup.inlineKeyboard([[Markup.button.callback("✅ I Completed It", `complete:${attempt.id}`)]])
      }
    );
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});

bot.action(/^complete:(\d+)$/, async ctx => {
  await ctx.answerCbQuery();
  try {
    const u = await getUserByTelegramId(ctx.from.id);
    const amount = await completeManualTask(u.id, Number(ctx.match[1]));
    await ctx.reply(`🎉 Task completed.\n\n💰 ${process.env.CURRENCY || "₹"}${amount.toFixed(2)} added to your wallet.`);
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});

bot.action("invite", async ctx => {
  await ctx.answerCbQuery();
  const u = await getUserByTelegramId(ctx.from.id);
  const s = await stats(u.id);
  const me = await ctx.telegram.getMe();
  const link = `https://t.me/${me.username}?start=ref_${ctx.from.id}`;
  await ctx.reply(
`👥 *Invite & Earn*

Your referral link:
\`${link}\`

👤 Invited: ${s.total}
✅ Qualified: ${s.qualified}
💰 Referral earnings: ${process.env.CURRENCY || "₹"}${Number(s.earned).toFixed(2)}

A referral qualifies only after completing the configured qualifying activity.`,
    { parse_mode: "Markdown", ...mainMenu() }
  );
});

bot.action("account", async ctx => {
  await ctx.answerCbQuery();
  const u = await getUserByTelegramId(ctx.from.id);
  const s = await stats(u.id);
  await ctx.reply(
`👤 *ACCOUNT*

🆔 ${u.telegram_id}
📅 Joined: ${new Date(u.created_at).toLocaleDateString()}

💰 Balance: ${process.env.CURRENCY || "₹"}${Number(u.balance).toFixed(2)}
🎁 Lifetime earned: ${process.env.CURRENCY || "₹"}${Number(u.lifetime_earned).toFixed(2)}
💸 Lifetime withdrawn: ${process.env.CURRENCY || "₹"}${Number(u.lifetime_withdrawn).toFixed(2)}
👥 Referrals: ${s.total}
✅ Qualified: ${s.qualified}`,
    { parse_mode: "Markdown", ...mainMenu() }
  );
});

bot.action("cashout", async ctx => {
  await ctx.answerCbQuery();
  const u = await getUserByTelegramId(ctx.from.id);
  const min = Number(await getSetting("min_withdrawal", process.env.MIN_WITHDRAWAL || "100"));
  await ctx.reply(
`💸 *CASHOUT*

Available: ${process.env.CURRENCY || "₹"}${Number(u.balance).toFixed(2)}
Minimum: ${process.env.CURRENCY || "₹"}${min.toFixed(2)}

Use:
\`/withdraw 120 upi yourupi@bank\`

The request will be held for admin review.`,
    { parse_mode: "Markdown", ...mainMenu() }
  );
});

bot.command("withdraw", async ctx => {
  try {
    if (!(await requireVerified(ctx))) return;
    const parts = ctx.message.text.trim().split(/\s+/);
    if (parts.length < 4) return ctx.reply("Usage: /withdraw 120 upi yourupi@bank");
    const amount = Number(parts[1]);
    const method = parts[2];
    const destination = parts.slice(3).join(" ");
    const min = Number(await getSetting("min_withdrawal", process.env.MIN_WITHDRAWAL || "100"));
    if (!Number.isFinite(amount) || amount < min) return ctx.reply(`Minimum withdrawal is ${process.env.CURRENCY || "₹"}${min}.`);
    const u = await getUserByTelegramId(ctx.from.id);
    const w = await debitForWithdrawal(u.id, amount, method, destination);
    await ctx.reply(`⏳ Withdrawal request created.\n\nID: WD-${w.id}\nAmount: ${process.env.CURRENCY || "₹"}${amount.toFixed(2)}\nStatus: Pending`);
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});

bot.action("history", async ctx => {
  await ctx.answerCbQuery();
  const u = await getUserByTelegramId(ctx.from.id);
  const rows = await history(u.id);
  if (!rows.length) return ctx.reply("📜 No transactions yet.", mainMenu());
  const text = rows.map(x => `${new Date(x.created_at).toLocaleString()} — ${x.type} — ${Number(x.amount).toFixed(2)} — ${x.status}`).join("\n");
  await ctx.reply(`📜 *Transaction History*\n\n${text}`, { parse_mode: "Markdown", ...mainMenu() });
});

bot.action("gift", async ctx => {
  await ctx.answerCbQuery();
  await ctx.reply("🎟 Send your gift code using:\n`/gift CODE`\n\nExample: `/gift WELCOME120`", { parse_mode: "Markdown" });
});

bot.command("gift", async ctx => {
  try {
    if (!(await requireVerified(ctx))) return;
    const code = ctx.message.text.split(/\s+/)[1];
    if (!code) return ctx.reply("Usage: /gift CODE");
    const u = await getUserByTelegramId(ctx.from.id);
    const amount = await redeem(u.id, code);
    await ctx.reply(`🎉 Gift code redeemed!\n\n💰 ${process.env.CURRENCY || "₹"}${amount.toFixed(2)} added.`);
  } catch (e) {
    await ctx.reply(`❌ ${e.message}`);
  }
});

bot.action("support", async ctx => {
  await ctx.answerCbQuery();
  const s = await getSetting("support_username", process.env.SUPPORT_USERNAME || "");
  await ctx.reply(s ? `🆘 Support: @${s.replace("@","")}` : "🆘 Support is not configured yet.", mainMenu());
});

bot.catch(err => console.error("BOT ERROR", err));

module.exports = { bot };
