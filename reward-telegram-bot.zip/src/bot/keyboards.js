const { Markup } = require("telegraf");

function mainMenu() {
  return Markup.inlineKeyboard([
    [Markup.button.callback("🎁 Tasks", "tasks"), Markup.button.callback("💰 Cashout", "cashout")],
    [Markup.button.callback("👥 Invite", "invite"), Markup.button.callback("👤 Account", "account")],
    [Markup.button.callback("🎟 Gift Code", "gift"), Markup.button.callback("📜 History", "history")],
    [Markup.button.callback("🆘 Support", "support")]
  ]);
}

function joinKeyboard(channels) {
  const rows = channels.map(c => [
    Markup.button.url(`📢 ${c.title}`, c.invite_url || `https://t.me/${String(c.username || "").replace("@","")}`)
  ]);
  rows.push([Markup.button.callback("✅ Verify Membership", "verify")]);
  return Markup.inlineKeyboard(rows);
}

module.exports = { mainMenu, joinKeyboard };
