async function requiredChannelsJoined(ctx, channels) {
  for (const c of channels) {
    try {
      const member = await ctx.telegram.getChatMember(c.chat_id, ctx.from.id);
      const ok = ["creator", "administrator", "member"].includes(member.status) ||
        (member.status === "restricted" && member.is_member);
      if (!ok) return false;
    } catch (_) {
      return false;
    }
  }
  return true;
}
module.exports = { requiredChannelsJoined };
