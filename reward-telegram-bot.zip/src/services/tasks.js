const { query, tx } = require("../db");
const { creditUser } = require("./wallet");

async function listActiveTasks() {
  const r = await query(`
    SELECT * FROM tasks WHERE active=true ORDER BY id DESC
  `);
  return r.rows;
}

async function startTask(userId, taskId) {
  const r = await query("SELECT * FROM tasks WHERE id=$1 AND active=true", [taskId]);
  if (!r.rows[0]) throw new Error("Task unavailable");
  const task = r.rows[0];

  const count = await query(`
    SELECT COUNT(*)::int AS n FROM task_attempts
    WHERE user_id=$1 AND task_id=$2
      AND created_at >= date_trunc('day', NOW())
  `, [userId, taskId]);

  if (count.rows[0].n >= task.daily_limit) throw new Error("Daily limit reached");

  if (task.cooldown_seconds > 0) {
    const recent = await query(`
      SELECT created_at FROM task_attempts
      WHERE user_id=$1 AND task_id=$2
      ORDER BY created_at DESC LIMIT 1
    `, [userId, taskId]);
    if (recent.rows[0]) {
      const age = (Date.now() - new Date(recent.rows[0].created_at).getTime()) / 1000;
      if (age < task.cooldown_seconds) throw new Error(`Please wait ${Math.ceil(task.cooldown_seconds-age)} seconds`);
    }
  }

  const a = await query(`
    INSERT INTO task_attempts(task_id,user_id,status,provider_ref)
    VALUES($1,$2,'started',$3) RETURNING *
  `, [taskId, userId, `MANUAL-${Date.now()}-${userId}`]);

  return { task, attempt: a.rows[0] };
}

async function completeManualTask(userId, attemptId) {
  return tx(async client => {
    const a = await client.query(`
      SELECT a.*, t.reward, t.title
      FROM task_attempts a JOIN tasks t ON t.id=a.task_id
      WHERE a.id=$1 AND a.user_id=$2
      FOR UPDATE
    `, [attemptId, userId]);

    if (!a.rows[0]) throw new Error("Task attempt not found");
    if (a.rows[0].status !== "started") throw new Error("Task already processed");

    await client.query("UPDATE task_attempts SET status='completed',completed_at=NOW() WHERE id=$1", [attemptId]);

    const amount = Number(a.rows[0].reward);
    await client.query("UPDATE users SET balance=balance+$2,lifetime_earned=lifetime_earned+$2,updated_at=NOW() WHERE id=$1", [userId, amount]);
    await client.query(`
      INSERT INTO wallet_transactions(user_id,type,amount,reference,note)
      VALUES($1,'task_reward',$2,$3,$4)
    `, [userId, amount, `TASK-${attemptId}`, a.rows[0].title]);

    return amount;
  });
}

module.exports = { listActiveTasks, startTask, completeManualTask };
