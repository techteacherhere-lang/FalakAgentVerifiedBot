const { tx, query } = require("../db");

async function creditUser(userId, amount, type, reference, note) {
  if (Number(amount) <= 0) throw new Error("Amount must be positive");
  return tx(async client => {
    const u = await client.query("SELECT balance,lifetime_earned FROM users WHERE id=$1 FOR UPDATE", [userId]);
    if (!u.rows[0]) throw new Error("User not found");
    const newBalance = Number(u.rows[0].balance) + Number(amount);
    await client.query("UPDATE users SET balance=$2,lifetime_earned=lifetime_earned+$3,updated_at=NOW() WHERE id=$1", [userId, newBalance, amount]);
    await client.query(`
      INSERT INTO wallet_transactions(user_id,type,amount,reference,note)
      VALUES($1,$2,$3,$4,$5)
    `, [userId, type, amount, reference || null, note || null]);
    return newBalance;
  });
}

async function debitForWithdrawal(userId, amount, method, destination) {
  return tx(async client => {
    const u = await client.query("SELECT balance FROM users WHERE id=$1 FOR UPDATE", [userId]);
    if (!u.rows[0]) throw new Error("User not found");
    if (Number(u.rows[0].balance) < Number(amount)) throw new Error("Insufficient balance");

    const w = await client.query(`
      INSERT INTO withdrawals(user_id,amount,method,destination)
      VALUES($1,$2,$3,$4) RETURNING *
    `, [userId, amount, method, destination]);

    await client.query("UPDATE users SET balance=balance-$2,updated_at=NOW() WHERE id=$1", [userId, amount]);
    await client.query(`
      INSERT INTO wallet_transactions(user_id,type,amount,status,reference,note)
      VALUES($1,'withdrawal',$2,'pending',$3,$4)
    `, [userId, -Number(amount), `WD-${w.rows[0].id}`, `Withdrawal via ${method}`]);

    return w.rows[0];
  });
}

async function refundWithdrawal(withdrawalId, adminNote = "Withdrawal rejected") {
  return tx(async client => {
    const w = await client.query("SELECT * FROM withdrawals WHERE id=$1 FOR UPDATE", [withdrawalId]);
    if (!w.rows[0]) throw new Error("Withdrawal not found");
    if (w.rows[0].status !== "pending") throw new Error("Withdrawal is not pending");

    await client.query("UPDATE withdrawals SET status='rejected',admin_note=$2,processed_at=NOW() WHERE id=$1", [withdrawalId, adminNote]);
    await client.query("UPDATE users SET balance=balance+$2,updated_at=NOW() WHERE id=$1", [w.rows[0].user_id, w.rows[0].amount]);
    await client.query(`
      INSERT INTO wallet_transactions(user_id,type,amount,reference,note)
      VALUES($1,'withdrawal_refund',$2,$3,$4)
    `, [w.rows[0].user_id, w.rows[0].amount, `WD-${withdrawalId}`, adminNote]);
  });
}

async function markWithdrawalPaid(withdrawalId, adminNote = "Marked paid by admin") {
  return tx(async client => {
    const w = await client.query("SELECT * FROM withdrawals WHERE id=$1 FOR UPDATE", [withdrawalId]);
    if (!w.rows[0]) throw new Error("Withdrawal not found");
    if (w.rows[0].status !== "pending") throw new Error("Withdrawal is not pending");
    await client.query("UPDATE withdrawals SET status='paid',admin_note=$2,processed_at=NOW() WHERE id=$1", [withdrawalId, adminNote]);
    await client.query("UPDATE users SET lifetime_withdrawn=lifetime_withdrawn+$2,updated_at=NOW() WHERE id=$1", [w.rows[0].user_id, w.rows[0].amount]);
    await client.query(`
      UPDATE wallet_transactions SET status='confirmed',note=$2
      WHERE reference=$1 AND type='withdrawal'
    `, [`WD-${withdrawalId}`, adminNote]);
  });
}

async function history(userId, limit=20) {
  const r = await query(`
    SELECT * FROM wallet_transactions WHERE user_id=$1
    ORDER BY created_at DESC LIMIT $2
  `, [userId, limit]);
  return r.rows;
}

module.exports = { creditUser, debitForWithdrawal, refundWithdrawal, markWithdrawalPaid, history };
