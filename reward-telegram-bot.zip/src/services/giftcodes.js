const { tx } = require("../db");

async function redeem(userId, rawCode) {
  const code = String(rawCode).trim().toUpperCase();
  return tx(async client => {
    const r = await client.query("SELECT * FROM gift_codes WHERE code=$1 AND active=true FOR UPDATE", [code]);
    if (!r.rows[0]) throw new Error("Invalid or inactive code");
    const g = r.rows[0];
    if (g.expires_at && new Date(g.expires_at) < new Date()) throw new Error("Code expired");
    if (g.used_count >= g.max_uses) throw new Error("Code usage limit reached");

    const used = await client.query("SELECT 1 FROM gift_code_redemptions WHERE gift_code_id=$1 AND user_id=$2", [g.id, userId]);
    if (used.rows[0]) throw new Error("You already used this code");

    await client.query("INSERT INTO gift_code_redemptions(gift_code_id,user_id,amount) VALUES($1,$2,$3)", [g.id,userId,g.amount]);
    await client.query("UPDATE gift_codes SET used_count=used_count+1 WHERE id=$1", [g.id]);
    await client.query("UPDATE users SET balance=balance+$2,lifetime_earned=lifetime_earned+$2 WHERE id=$1", [userId,g.amount]);
    await client.query(`
      INSERT INTO wallet_transactions(user_id,type,amount,reference,note)
      VALUES($1,'gift_code',$2,$3,$4)
    `, [userId,g.amount,`GIFT-${g.id}`,`Gift code ${code}`]);

    return Number(g.amount);
  });
}

module.exports = { redeem };
