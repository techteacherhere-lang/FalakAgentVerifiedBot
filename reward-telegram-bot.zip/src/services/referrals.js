const { query, tx } = require("../db");
const { getSetting } = require("./settings");

async function qualifyReferral(referredUserId) {
  return tx(async client => {
    const r = await client.query(`
      SELECT r.*, u.telegram_id AS referrer_telegram
      FROM referrals r JOIN users u ON u.id=r.referrer_id
      WHERE r.referred_user_id=$1 AND r.status='pending'
      FOR UPDATE
    `, [referredUserId]);

    if (!r.rows[0]) return null;
    const reward = Number(await getSetting("referral_reward", "10"));

    await client.query("UPDATE referrals SET status='qualified',reward_amount=$2,qualified_at=NOW() WHERE id=$1", [r.rows[0].id, reward]);
    await client.query("UPDATE users SET balance=balance+$2,lifetime_earned=lifetime_earned+$2 WHERE id=$1", [r.rows[0].referrer_id, reward]);
    await client.query(`
      INSERT INTO wallet_transactions(user_id,type,amount,reference,note)
      VALUES($1,'referral_reward',$2,$3,$4)
    `, [r.rows[0].referrer_id, reward, `REF-${r.rows[0].id}`, "Qualified referral"]);
    return { telegramId: r.rows[0].referrer_telegram, reward };
  });
}

async function stats(userId) {
  const r = await query(`
    SELECT
      COUNT(*) FILTER (WHERE status='qualified')::int AS qualified,
      COUNT(*)::int AS total,
      COALESCE(SUM(reward_amount),0) AS earned
    FROM referrals WHERE referrer_id=$1
  `, [userId]);
  return r.rows[0];
}

module.exports = { qualifyReferral, stats };
