const { query, tx } = require("../db");

async function upsertUser(tgUser, startParam = null) {
  return tx(async client => {
    const existing = await client.query("SELECT * FROM users WHERE telegram_id=$1", [tgUser.id]);
    if (existing.rows[0]) {
      await client.query(`
        UPDATE users SET username=$2, first_name=$3, last_name=$4, updated_at=NOW()
        WHERE telegram_id=$1
      `, [tgUser.id, tgUser.username || null, tgUser.first_name || "", tgUser.last_name || null]);
      return existing.rows[0];
    }

    let referrerId = null;
    if (startParam && startParam.startsWith("ref_")) {
      const refTelegramId = Number(startParam.slice(4));
      if (Number.isSafeInteger(refTelegramId) && refTelegramId !== tgUser.id) {
        const rr = await client.query("SELECT id FROM users WHERE telegram_id=$1", [refTelegramId]);
        referrerId = rr.rows[0]?.id || null;
      }
    }

    const created = await client.query(`
      INSERT INTO users(telegram_id,username,first_name,last_name,referred_by)
      VALUES($1,$2,$3,$4,$5)
      RETURNING *
    `, [tgUser.id, tgUser.username || null, tgUser.first_name || "", tgUser.last_name || null, referrerId]);

    if (referrerId) {
      await client.query(`
        INSERT INTO referrals(referrer_id,referred_user_id)
        VALUES($1,$2) ON CONFLICT(referred_user_id) DO NOTHING
      `, [referrerId, created.rows[0].id]);
    }
    return created.rows[0];
  });
}

async function getUserByTelegramId(telegramId) {
  const r = await query("SELECT * FROM users WHERE telegram_id=$1", [telegramId]);
  return r.rows[0];
}

async function getUserById(id) {
  const r = await query("SELECT * FROM users WHERE id=$1", [id]);
  return r.rows[0];
}

module.exports = { upsertUser, getUserByTelegramId, getUserById };
