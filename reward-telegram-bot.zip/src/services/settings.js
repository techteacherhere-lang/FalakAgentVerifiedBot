const { query } = require("../db");

async function getSetting(key, fallback = "") {
  const r = await query("SELECT value FROM settings WHERE key=$1", [key]);
  return r.rows[0]?.value ?? fallback;
}

async function setSetting(key, value) {
  await query(`
    INSERT INTO settings(key,value) VALUES($1,$2)
    ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value
  `, [key, String(value)]);
}

module.exports = { getSetting, setSetting };
