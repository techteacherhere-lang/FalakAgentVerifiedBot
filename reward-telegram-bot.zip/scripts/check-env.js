require("dotenv").config();
const required = ["BOT_TOKEN","DATABASE_URL","JWT_SECRET","WEBHOOK_SECRET"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing:", missing.join(", "));
  process.exit(1);
}
console.log("Environment looks complete.");
